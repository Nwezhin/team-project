<?php
include 'connect.php';

$result = mysqli_query($conn, "SELECT * FROM donors");
while($row = mysqli_fetch_assoc($result)){
    echo "Name: " . $row['name'] . " | Blood Group: " . $row['blood_group'] . "<br>";
}
?>