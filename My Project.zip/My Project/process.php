<?php
include 'connect.php';

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $bloodGroup = $_POST['bloodGroup'];
    $healthRecord = $_POST['healthRecord'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $sql = "INSERT INTO donor (name, gender, age, bloodGroup, healthRecord, phone, address)
            VALUES ('$name', '$gender', '$age', '$bloodGroup','$healthRecord', '$phone', '$address')";

    if(mysqli_query($conn, $sql)) {
        echo "Donor Registered Successfully!";
    }else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>