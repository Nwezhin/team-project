<?php
include 'connect.php';
$result = mysqli_query($conn, "SELECT * FROM messages");
while($row = mysqli_fetch_assoc($result)){
    echo "From: " . $row['name'] . "<br>Message: " . $row['message'] . "<hr>"
}
?>