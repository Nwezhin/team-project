<?php
include 'connect.php';

if (isset($_POST['blood_group'])) {
    $blood_group = $_POST['blood_group'];

    $sql = "SELECT * FROM blood WHERE blood_group='$blood_group'";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
        echo "Blood Group: " . $row['blood_group'] . "| Quantity: " . $row['quantity'] . "<br>";
    }
}
?>