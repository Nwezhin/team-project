<?php
include 'connect.php';

if (isset($_POST['blood_group']) && isset($_POST['quantity'])) {
    $blood_group = $_POST['blood_group'];
    $quantity = $_POST['quantity'];

    $sql = "INSERT INTO blood (blood_group, quantity) VALUES ('$blood_groub', '$quantity')";

    if (mysqli_query($conn, $sql)) {
        echo "Blood Added!";
    }else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>