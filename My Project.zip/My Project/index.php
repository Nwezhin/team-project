<?php
echo "hello"

?>