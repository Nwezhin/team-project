<?php
include 'connect.php';

$sql = "SELECT * FROM blood";
$result = mysqli_query($conn, $sql);

?>

<h2>Available Blood Details</h2>
<table border ="1">
    <tr>
        <th>Blood ID</th>
        <th>Doner ID</th>
        <th>Blood Type</th>
        <th>Quantity</th>
        <th>Date</th>
        <th>Time</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($result)) {?>
        <tr>
            <td><?= $row['BID']?></td>
            <td><?= $row['DID']?></td>
            <td><?= $row['BloodType']?></td>
            <td><?= $row['quantity']?></td>
            <td><?= $row['date']?></td>
            <td><?= $row['time']?></td>
        </tr>
    <?php } ?>
</table>



